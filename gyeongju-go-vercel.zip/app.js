const courses=[
 {type:"cafe",name:"골목 테이크아웃 상점",meta:"카페 · 왕복 480m · 도보 8분",desc:"가볍게 들러 이번 버스 전까지 다녀오기 좋아요.",time:"16분"},
 {type:"food",name:"골목 한식 맛집",meta:"맛집 · 왕복 600m · 도보 10분",desc:"든든한 한 끼와 함께 다음 버스를 기다려보세요.",time:"38분"},
 {type:"walk",name:"원도심 골목 산책",meta:"산책 · 왕복 420m · 도보 7분",desc:"천천히 걸으며 경주의 오래된 풍경을 만나보세요.",time:"22분"}
];
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function show(view){
  $$(".view").forEach(v=>v.classList.toggle("active",v.dataset.view===view));
  $$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.nav===view));
  window.scrollTo({top:0,behavior:"smooth"});
  if(view==="course") loadMap();
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function renderCourses(filter="all", target="#homeCourses"){
 const list=filter==="all"?courses:courses.filter(c=>c.type===filter);
 $(target).innerHTML=list.map(c=>`<article class="course-card"><span class="tag">${c.type==="cafe"?"카페":c.type==="food"?"맛집":"산책"}</span><h3>${c.name}</h3><p>${c.meta}</p><div class="card-foot"><span class="muted">${c.desc}</span><button class="small-btn" data-action="start">둘러보기</button></div></article>`).join("");
}
function loadMap(){
  if(window.naver && naver.maps){
    const el=$("#map"); el.innerHTML="";
    const map=new naver.maps.Map(el,{center:new naver.maps.LatLng(35.8354,129.2139),zoom:15});
    new naver.maps.Marker({position:new naver.maps.LatLng(35.8354,129.2139),map,title:"경주 GO 추천 코스"});
  }
}
async function tryLocation(){
 if(!navigator.geolocation)return toast("이 브라우저는 위치 기능을 지원하지 않아요.");
 navigator.geolocation.getCurrentPosition(p=>toast(`현재 위치를 확인했어요 (${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)})`),()=>toast("위치 권한을 허용하면 현재 위치를 사용할 수 있어요."));
}
function startScan(){show("scan")}
function recognize(){show("loading");setTimeout(()=>show("course"),1000)}
document.addEventListener("click",e=>{
 const action=e.target.closest("[data-action]")?.dataset.action;
 const nav=e.target.closest("[data-nav]")?.dataset.nav;
 if(nav) show(nav);
 if(action==="home")show("home");
 if(action==="scan")startScan();
 if(action==="course")show("course");
 if(action==="recognize")recognize();
 if(action==="start"){toast("코스를 여행 기록에 추가했어요.");show("record")}
 if(action==="saveReview"){localStorage.setItem("gyeongjuGoReview",$("#review").value);localStorage.setItem("gyeongjuGoRating",document.querySelectorAll(".stars .active").length||5);toast("후기가 저장됐어요.");show("mypage")}
});
$$(".chip").forEach(ch=>ch.addEventListener("click",()=>{$$(".chip").forEach(x=>x.classList.remove("selected"));ch.classList.add("selected");renderCourses(ch.dataset.filter)}));
$("#locationBtn").addEventListener("click",tryLocation);
$$(".stars button").forEach((b,i)=>b.addEventListener("click",()=>$$(".stars button").forEach((x,j)=>{x.textContent=j<=i?"★":"☆";x.classList.toggle("active",j<=i)})));
$("#recordDate").textContent=new Date().toLocaleDateString("ko-KR",{month:"long",day:"numeric"});
renderCourses();
$("#courseList").innerHTML=courses.map(c=>`<article class="course-card"><span class="tag">${c.type==="cafe"?"카페":c.type==="food"?"맛집":"산책"}</span><h3>${c.name}</h3><p>${c.meta}</p><div class="card-foot"><span class="muted">${c.desc}</span><button class="small-btn" data-action="start">출발하기</button></div></article>`).join("");
if("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
