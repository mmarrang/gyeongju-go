# 경주 GO — Vercel 배포용 웹앱

두 개의 경주 GO 디자인 HTML을 참고해 모바일 앱처럼 동작하도록 정리한 정적 웹앱입니다.

## 포함 기능
- QR 스캔/인식 시연 흐름
- 코스 추천 및 필터
- 현재 위치 권한 요청
- 후기·별점 저장(localStorage)
- PWA 설치 가능 구조
- 네이버 지도 API 연결 자리 포함
- Vercel/Netlify/GitHub Pages 정적 배포 가능

## Vercel 배포
1. 이 폴더의 파일을 GitHub 저장소에 업로드합니다.
2. Vercel에서 `Add New → Project`를 선택합니다.
3. GitHub 저장소를 연결합니다.
4. Framework Preset은 `Other`, Build Command는 비워두고 Deploy합니다.
5. 생성된 HTTPS 주소를 사용합니다.

## 네이버 지도 API 연결
`index.html`의 `</head>` 위에 아래 스크립트를 추가하고 `YOUR_NAVER_CLIENT_ID`를 발급받은 값으로 바꿉니다.

```html
<script src="https://oapi.map.naver.com/openapi/v3/maps.js?ncpClientId=YOUR_NAVER_CLIENT_ID"></script>
```

네이버 Cloud Platform 콘솔의 애플리케이션 설정에서 배포된 도메인을 Web 서비스 URL로 등록하세요.
예:
`https://your-project.vercel.app`

현재 API 키가 없으면 지도 영역이 안내 문구로 표시되고 앱의 나머지 기능은 정상 작동합니다.

## QR 카메라 연결
현재는 디자인 시연용 QR 인식 버튼을 제공합니다. 실제 카메라 QR 인식은 HTTPS 배포 후 `BarcodeDetector` 또는 별도 QR 라이브러리를 연결하면 됩니다. 카메라 권한은 반드시 HTTPS 환경에서만 동작합니다.

## 주의
- 네이버 지도 클라이언트 ID는 브라우저에 노출되는 값이므로 네이버 콘솔에서 허용 도메인을 반드시 제한하세요.
- 후기와 여행 기록은 현재 브라우저 localStorage에 저장됩니다. 여러 사용자의 계정별 저장이 필요하면 Supabase/Firebase를 연결해야 합니다.
